<?php $__env->startSection('content'); ?>

    <form method="POST">
        <?php echo csrf_field(); ?>
       <input type="hidden" name="id" value="<?php echo e($myAlbum->id); ?>" id="">
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Album</label>
            <input type="text" value="<?php echo e($myAlbum->nome); ?>" name="nome" class="form-control" id="exampleFormControlInput1" placeholder="Nome" readonly>
          </div>
          <div class="mb-3">
            <?php if($myAlbum->imagem): ?>
                <img src="<?php echo e($myAlbum->imagem); ?>" alt="Imagem do álbum" style="width: 150px; height: 100px;"><br>
            <?php endif; ?>
            <label for="exampleFormControlInput1" class="form-label">Imagem</label>
            <input type="text" value="<?php echo e($myAlbum->imagem); ?>" name="imagem" class="form-control" id="exampleFormControlInput1" readonly>
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Data Lançamento</label>
            <input type="text"  value="<?php echo e($myAlbum->data_lancamento); ?>" name = "data_lancamento" class="form-control" id="exampleFormControlInput1" readonly>
          </div>
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Banda</label>
            <input type="text" value="<?php echo e($myAlbum->bandaNome); ?>" name = "banda_id" class="form-control" id="exampleFormControlInput1" readonly>
          </div>
    </form>
    <br>
    <a class= "btn btn-success" href="<?php echo e(route('albuns.all')); ?>">Voltar</a>
    <?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('albuns.verUpdate', ['id' => $myAlbum->id])); ?>" class="btn btn-info">Editar</a>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/albuns/albunsView.blade.php ENDPATH**/ ?>