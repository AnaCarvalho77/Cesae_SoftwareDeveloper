<?php $__env->startSection('content'); ?>
    <div class="container">
        <br>
        <h2>Adicionar Albuns</h2>
        <br>


        <form method="POST" action="<?php echo e(route('albuns.create')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Album</label>
                <input type="text" value="<?php echo e(old('nome')); ?>" name="nome" class="form-control"
                    id="exampleFormControlInput1" placeholder="Nome" required>
                <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class='alert alert-danger'>
                        Album inválido
                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Imagem</label>
                <input type="file" value="<?php echo e(old('imagem')); ?>" name = "imagem" class="form-control"
                    id="exampleFormControlInput1">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Data Lançamento</label>
                <input type="date" value="<?php echo e(old('data_lancamento')); ?>" name = "data_lancamento" class="form-control"
                    id="exampleFormControlInput1">
            </div>
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">Banda</label>
                <select name="banda_id" id="">
                    <?php $__currentLoopData = $bandas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($banda->id); ?>">
                        <?php echo e($banda->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php $__errorArgs = ['banda_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class='alert alert-danger'> Não pode atribuir este album a esta banda</div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
        </form>
        <br>
        <a class= "btn btn-success" href="<?php echo e(route('albuns.all')); ?>">Voltar</a>

        <button type="submit" class="btn btn-primary">Enviar</button>
        <br>
        <br>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/albuns/insert_albuns.blade.php ENDPATH**/ ?>