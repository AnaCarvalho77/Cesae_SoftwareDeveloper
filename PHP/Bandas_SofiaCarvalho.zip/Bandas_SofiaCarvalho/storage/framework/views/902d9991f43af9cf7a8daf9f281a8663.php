<?php $__env->startSection('content'); ?>
    <br><br>
    <h1>Utilizadores</h1>
    <br>
    <br>
    <form action="" method="GET">
        <input type="text" value="<?php echo e(request()->query('search')); ?>" name="search" id="" placeholder="Procurar">
        <button class = "btn btn-secondary" type="submit">Procurar</button>
    </form>

    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>


    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope='row'><?php echo e($item->id); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><a href="<?php echo e(route('users.view', $item->id)); ?>" class="btn btn-info">Ver</a></td>
                    <?php if(auth()->guard()->check()): ?>
                        <td><a href="<?php echo e(route('users.verUpdate', $item->id)); ?>" class="btn btn-info">Editar</a></td>
                        <?php if(Auth::user()->user_type == 1): ?>
                            <td><a href="<?php echo e(route('users.delete', $item->id)); ?>" class="btn btn-danger">Apagar</a></td>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a class= "btn btn-success" href="<?php echo e(route('home.index')); ?>">Voltar</a>
    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->user_type == 1): ?>
            <a href="<?php echo e(route('users.add', $item->id)); ?>" class="btn btn-info">Inserir utilizador</a></td>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/users/all_users.blade.php ENDPATH**/ ?>