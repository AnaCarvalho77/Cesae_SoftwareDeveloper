<?php $__env->startSection('content'); ?>
    <h1>Ver dados <?php echo e($myUser->name); ?></h1>
    <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($myUser->id); ?>" id="">
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Nome</label>
            <input type="text" value="<?php echo e($myUser->name); ?>" class="form-control" id="exampleFormControlInput1" readonly>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Email</label>
            <input type="email" value="<?php echo e($myUser->email); ?>" class="form-control" id="exampleFormControlInput1" readonly>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Morada</label>
            <input type="text" value="<?php echo e($myUser->address); ?>" class="form-control" id="exampleFormControlInput1"
                readonly>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Telefone</label>
            <input type="text" value="<?php echo e($myUser->phone); ?>" class="form-control" id="exampleFormControlInput1" readonly>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Foto</label><br>
            <?php if($myUser->foto): ?>
                <img src="data:image/jpeg;base64,<?php echo e(base64_encode($myUser->foto)); ?>" alt="Foto do usuário">
            <?php else: ?>
                <p>Sem foto</p>
            <?php endif; ?>
        </div>

    </form>

    <a class= "btn btn-success" href="<?php echo e(route('users.all')); ?>">Voltar</a>
    <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('users.verUpdate', ['id' => $myUser->id])); ?>" class="btn btn-info">Editar</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/users/usersView.blade.php ENDPATH**/ ?>