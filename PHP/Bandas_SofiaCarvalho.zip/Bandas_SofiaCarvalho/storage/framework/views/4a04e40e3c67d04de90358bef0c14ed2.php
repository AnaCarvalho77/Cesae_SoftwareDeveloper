<?php $__env->startSection('content'); ?>
    <h1>Atualizar dados <?php echo e($myUser->name); ?></h1>
    <form method="POST" action="<?php echo e(route('users.update')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($myUser->id); ?>" id="">
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Nome</label>
            <input type="texto" value="<?php echo e($myUser->name); ?>" name="name" class="form-control"
                id="exampleFormControlInput1" placeholder="Nome" required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class='alert alert-danger'>
                    O nome que colocou é inválido!
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Email</label>
            <input disabled type="email" value="<?php echo e($myUser->email); ?>" name = "email" class="form-control"
                id="exampleFormControlInput1" placeholder="email@exemplo.com" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class='alert alert-danger'>
                    Este email já está registado!
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Morada</label>
            <input type="address" value="<?php echo e($myUser->address); ?>" name = "address" class="form-control"
                id="exampleFormControlInput1">
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class='alert alert-danger'>
                    Morada incorrecta!
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Telefone</label>
            <input type="phone" value="<?php echo e($myUser->phone); ?>" name = "phone" class="form-control"
                id="exampleFormControlInput1">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class='alert alert-danger'>
                    Telefone incorrecto!
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </form>
    <a class= "btn btn-success" href="<?php echo e(route('users.all')); ?>">Voltar</a>
    <button type="submit" class="btn btn-primary">Atualizar</button>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/users/usersUpdate.blade.php ENDPATH**/ ?>