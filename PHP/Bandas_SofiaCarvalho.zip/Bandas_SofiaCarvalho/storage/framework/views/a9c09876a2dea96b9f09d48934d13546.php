<?php $__env->startSection('content'); ?>
    <h1>Administrador(a)
        <?php if(auth()->guard()->check()): ?>
            <?php echo e(Auth::user()->name); ?>

        <?php endif; ?>
    </h1>

    <br><br>
    <?php if(auth()->guard()->check()): ?>
        <?php if($message): ?>
            <div class="alert alert-primary" role="alert">
                Conta de Administrador
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/dashboard/home.blade.php ENDPATH**/ ?>