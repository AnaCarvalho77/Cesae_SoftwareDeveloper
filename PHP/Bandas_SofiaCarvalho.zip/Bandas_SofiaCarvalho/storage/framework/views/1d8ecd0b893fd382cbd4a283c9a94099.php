<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <h3>BANDAS</h3>
    <br>
    <br>
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>


    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Foto</th>
                <th scope="col" class="text-center">Quantidade Albuns</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bandas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope='row'><?php echo e($index + 1); ?></th>
                    <td><?php echo e($item->nome); ?></td>
                    <td><img src = "<?php echo e($item->foto); ?>" alt="Imagem da Banda" style="width: 150px; height: 100px;"></td>
                    <?php if(isset($quantAlbuns[$index])): ?>
                        <td class="text-center"><?php echo e($quantAlbuns[$index]->qtAlbuns); ?></td>
                    <?php else: ?>
                        <td class="text-center">0</td>
                    <?php endif; ?>
                    <td><a href="<?php echo e(route('bandas.view', $item->id)); ?>" class="btn btn-secondary"><i
                                class="bi bi-eye-fill"></i> Ver</a></td>
                    <?php if(auth()->guard()->check()): ?>
                        <td><a href="<?php echo e(route('bandas.verUpdate', $item->id)); ?>" class="btn btn-secondary"><i
                                    class="bi bi-pencil-fill"></i> Editar</a></td>
                        <?php if(Auth::user()->user_type == 1): ?>
                            <td><a href="<?php echo e(route('bandas.delete', $item->id)); ?>" class="btn btn-danger"> <i
                                        class="bi bi-trash"></i> Eliminar</a></td>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a class= "btn btn-success" href="<?php echo e(route('home.index')); ?>">Voltar</a>

    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->user_type == 1): ?>
            <a href="<?php echo e(route('bandas.add', $item->id)); ?>" class="btn btn-info">Inserir banda</a></td>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/bandas/all_bandas.blade.php ENDPATH**/ ?>