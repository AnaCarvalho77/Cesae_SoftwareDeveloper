    <?php $__env->startSection('content'); ?>

<h1>Ups, estás perdido!</h1>
      <a href="<?php echo e(route('home.index')); ?>">Voltar</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/main/fallBack.blade.php ENDPATH**/ ?>