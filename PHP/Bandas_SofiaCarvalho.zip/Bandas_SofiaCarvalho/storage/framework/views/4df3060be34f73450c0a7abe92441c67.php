<?php $__env->startSection('content'); ?>
    <form method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($myBanda->id); ?>" id="">
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Nome</label>
            <input type="text" value="<?php echo e($myBanda->nome); ?>" name="nome" class="form-control"
                id="exampleFormControlInput1" placeholder="Nome" readonly>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Foto</label>
            <input type="text" value="<?php echo e($myBanda->foto); ?>" name = "foto" class="form-control"
                id="exampleFormControlInput1" readonly>
        </div>
    </form>
    <br>
    <a class= "btn btn-success" href="<?php echo e(route('bandas.all')); ?>">Voltar</a>
    <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('bandas.verUpdate', ['id' => $myBanda->id])); ?>" class="btn btn-info">Editar</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/bandas/bandasView.blade.php ENDPATH**/ ?>