<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <h3>ALBUNS</h3>
    <br>
    <br>
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>


    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Album</th>
                <th scope="col">Imagem</th>
                <th scope="col">Data de Lançamento</th>
                <th scope="col">Banda</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $albuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope='row'><?php echo e($index + 1); ?></th>
                    <td><?php echo e($item->nome); ?></td>
                    <td><img src="<?php echo e($item->imagem); ?>" alt="Imagem do album" style="width: 150px; height: 100px;"></td>
                    <td><?php echo e($item->data_lancamento); ?></td>
                    <td><?php echo e($item->bandaNome); ?></td>
                    <td><a href="<?php echo e(route('albuns.view', $item->id)); ?>" class="btn btn-secondary"><i
                                class="bi bi-eye-fill"></i> Ver</a></td>
                    <?php if(auth()->guard()->check()): ?>
                        <td><a href="<?php echo e(route('albuns.verUpdate', $item->id)); ?>" class="btn btn-secondary"><i
                                    class="bi bi-pencil-fill"></i> Editar</a></td>
                        <?php if(Auth::user()->user_type == 1): ?>
                            <td><a href="<?php echo e(route('albuns.delete', $item->id)); ?>" class="btn btn-danger"> <i
                                        class="bi bi-trash"></i> Eliminar</a></td>
                        <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a class= "btn btn-success" href="<?php echo e(route('home.index')); ?>">Voltar</a>

    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->user_type == 1): ?>
            <a href="<?php echo e(route('bandas.add', $item->id)); ?>" class="btn btn-info">Inserir album</a></td>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/albuns/all_albuns.blade.php ENDPATH**/ ?>