<?php $__env->startSection('content'); ?>
    <br><br><br>
    <h1>Bandas Sofia Carvalho</h1>

    <?php if(auth()->guard()->check()): ?>
        <h3> Olá, <?php echo e(Auth::user()->name); ?></h3>
    <?php endif; ?>
    <br>

    <div class="container">
        <div class="row row-cols-2">
            <div class="col">
                <div class="card mb-3" style="background-color: #399174">
                    <div class="card-body text-center">
                        <a href="<?php echo e(route('users.all')); ?>"
                            style="text-decoration: none; color: black;"><strong>Utilizadores</strong></a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-3" style="background-color:  #399174">
                    <div class="card-body text-center">
                        <a href="<?php echo e(route('bandas.all')); ?>"
                            style="text-decoration: none; color: black;"><strong>Bandas</strong></a>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-3" style="background-color:  #399174">
                    <div class="card-body text-center">
                        <a href="<?php echo e(route('albuns.all')); ?>"
                            style="text-decoration: none; color: black;"><strong>Albuns</strong></a>
                    </div>
                </div>
            </div>
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->user_type == 1): ?>
                    <div class="col">
                        <div class="card mb-3" style="background-color:  #399174">
                            <div class="card-body text-center">
                                <a href="<?php echo e(route('dashboard.home')); ?>"
                                    style="text-decoration: none; color: black;"><strong>Dashboard</strong></a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/main/home.blade.php ENDPATH**/ ?>