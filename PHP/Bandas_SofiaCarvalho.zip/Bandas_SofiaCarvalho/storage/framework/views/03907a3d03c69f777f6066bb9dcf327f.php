<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('albuns.update')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($myAlbum->id); ?>" id="">
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Nome Album</label>
            <input type="text" value="<?php echo e($myAlbum->nome); ?>" name="nome" class="form-control"
                id="exampleFormControlInput1" placeholder="Nome" required>
            <?php $__errorArgs = ['nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class='alert alert-danger'>
                    Album inválido
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Imagem</label>
            <input type="text" value="<?php echo e($myAlbum->imagem); ?>" name = "imagem" class="form-control"
                id="exampleFormControlInput1">
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Data Lançamento</label>
            <input type="text" value="<?php echo e($myAlbum->data_lancamento); ?>" name = "data_lancamento" class="form-control"
                id="exampleFormControlInput1">
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Banda</label>
            <select name="banda_id" id="">
                <option value="">Selecionar uma Banda</option>
                <?php $__currentLoopData = $bandas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($banda->id == $myAlbum->banda_id): ?> selected <?php endif; ?> value="<?php echo e($banda->id); ?>">
                        <?php echo e($banda->nome); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Atualizar</button>
    </form>
    <br>
    <a class= "btn btn-success" href="<?php echo e(route('albuns.all')); ?>">Voltar</a>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasofiacarvalho/Documents/GitHub/Cesae_SoftwareDeveloper/PHP/Bandas_SofiaCarvalho/resources/views/albuns/AlbunsUpdate.blade.php ENDPATH**/ ?>