@extends('layouts.femaster')


@section('content')
    <h1>Ups, estás perdido!</h1>
    <a href="{{ route('home.index') }}">Voltar</a>
@endsection
