package Domain;

/**
 * Enumeração de tipos de carro
 */
public enum TipoCarro {

    /**
     * tipos de carros
      */
    F1,Rally,GT
}
