
import View.JogoView;

import java.io.FileNotFoundException;

/**
 * calsse main para executar programa
 */
public class main {
    public static void main(String[] args) throws FileNotFoundException {
        JogoView.menuPiloto();

    }

}
