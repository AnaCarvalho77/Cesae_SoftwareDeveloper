import View.ClienteView;
import View.EntryView;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        EntryView.menuLogin();
    }
}
