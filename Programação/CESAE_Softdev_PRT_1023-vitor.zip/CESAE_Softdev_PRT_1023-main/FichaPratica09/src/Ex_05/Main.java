package Ex_05;


public class Main {
    public static void main(String[] args) {
        Carro mercedes = new Carro("Mercedes", "A45",2023);
        mercedes.ligar();
    }
}
