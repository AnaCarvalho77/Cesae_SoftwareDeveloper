package Pizzaria.Enums;

public enum TipoFrutoMar {
    CAMARAO,LAGOSTA,ATUM
}
