package Pizzaria.Enums;

public enum OrigemIngrediente {
    NACIONAL,IMPORTADA
}
