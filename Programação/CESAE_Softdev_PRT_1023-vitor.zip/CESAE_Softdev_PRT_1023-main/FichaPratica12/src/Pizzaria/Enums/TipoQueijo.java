package Pizzaria.Enums;

public enum TipoQueijo {
    MOZZARELA,SERRA,CABRA,OVELHA,BRIE,CHEDDAR
}
