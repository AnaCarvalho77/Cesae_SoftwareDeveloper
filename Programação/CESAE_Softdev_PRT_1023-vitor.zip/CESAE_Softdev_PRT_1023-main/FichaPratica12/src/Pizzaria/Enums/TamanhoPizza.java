package Pizzaria.Enums;

public enum TamanhoPizza {
    PEQUENA,MEDIA,GRANDE
}
