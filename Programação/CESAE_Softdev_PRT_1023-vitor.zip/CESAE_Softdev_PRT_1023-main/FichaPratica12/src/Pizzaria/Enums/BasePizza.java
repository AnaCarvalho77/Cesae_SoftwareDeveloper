package Pizzaria.Enums;

public enum BasePizza {
    FINA,ALTA
}
