package Pizzaria.Enums;

public enum TipoVegetal {
    CEBOLA,PIMENTO,COGUMELOS,MILHO,ANANAS
}
