package Pizzaria.Enums;

public enum UnidadeMedida {
    GRAMAS,LITROS,UNIDADES
}
