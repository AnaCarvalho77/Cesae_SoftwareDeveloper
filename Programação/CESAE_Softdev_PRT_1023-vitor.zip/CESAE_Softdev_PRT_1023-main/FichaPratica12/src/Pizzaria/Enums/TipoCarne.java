package Pizzaria.Enums;

public enum TipoCarne {
    PORCO,VACA,FRANGO,CHOURICO
}
