package Ex_02;

public enum TipoCombustivel {
    GASOLINA,DIESEL,GPL,ELETRICO
}
