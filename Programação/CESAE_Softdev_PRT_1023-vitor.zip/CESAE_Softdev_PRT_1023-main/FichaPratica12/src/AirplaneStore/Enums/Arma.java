package AirplaneStore.Enums;

public enum Arma {
    METRALHADORAS,MISSEIS,FOGUETES,TORPEDOS,BOMBAS
}
