package AirplaneStore.Enums;

public enum Instalacao {
    WC,CINEMA,SUITE,CHUVEIRO,TOMADAS,COZINHA,ESCRITORIO,WIFI
}
