package AirplaneStore.Enums;

public enum CategoriaJato {
    LIGHT_JET,MIDSIZE_JET,HEAVY_JET
}
