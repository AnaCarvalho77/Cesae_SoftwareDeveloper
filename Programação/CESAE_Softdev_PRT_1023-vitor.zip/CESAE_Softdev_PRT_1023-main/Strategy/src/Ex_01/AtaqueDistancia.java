package Ex_01;

public class AtaqueDistancia implements EstrategiaAtaque{
    @Override
    public void atacar() {
        System.out.println("Realizar um ataque à distância!");
    }
}
