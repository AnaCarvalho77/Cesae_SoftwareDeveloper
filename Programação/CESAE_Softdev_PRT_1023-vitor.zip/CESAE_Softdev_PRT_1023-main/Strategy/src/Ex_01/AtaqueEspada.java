package Ex_01;

public class AtaqueEspada implements EstrategiaAtaque{
    @Override
    public void atacar() {
        System.out.println("Realizar um ataque espada!");
    }
}
