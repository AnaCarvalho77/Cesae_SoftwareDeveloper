package Ex_01;

public interface EstrategiaAtaque {
    void atacar();
}
