package Ex_01;

public class AtaqueMagico implements EstrategiaAtaque{
    @Override
    public void atacar() {
        System.out.println("Realizar um ataque mágico!");
    }

}
