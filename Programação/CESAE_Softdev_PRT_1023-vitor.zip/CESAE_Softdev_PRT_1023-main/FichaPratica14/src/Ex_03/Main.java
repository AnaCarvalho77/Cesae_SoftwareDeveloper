package Ex_03;

public class Main {
    public static void main(String[] args) {

        Disciplina disciplinaNova = new Disciplina();
        disciplinaNova.exibirDetalhes();


    }
}
