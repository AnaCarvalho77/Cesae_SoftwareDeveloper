package Ex_03.Enums;

public enum Funcao {
    ADMINISTRACAO,RH,LIMPEZA,FINANCEIRA
}
