package Ex_01;

public enum TipoCombustivel {
    GASOLINA,DIESEL,GPL
}
