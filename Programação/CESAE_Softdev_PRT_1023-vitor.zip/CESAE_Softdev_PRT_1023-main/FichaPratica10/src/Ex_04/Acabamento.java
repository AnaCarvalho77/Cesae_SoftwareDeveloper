package Ex_04;

public enum Acabamento {
    PARA_RESTAURO,USADA,NOVA,NOVA_ALTO_ACABAMENTO
}
