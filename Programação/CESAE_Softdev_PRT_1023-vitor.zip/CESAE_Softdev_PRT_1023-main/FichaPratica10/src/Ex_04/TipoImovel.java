package Ex_04;

public enum TipoImovel {
    APARTAMENTO,CASA,MANSAO
}
