package FichaPratica07;

import java.io.FileNotFoundException;

import static FichaPratica07.BibliotecaFicheiros.imprimirFicheiro;

public class Ex_04 {
    public static void main(String[] args) throws FileNotFoundException {
        imprimirFicheiro("Ficheiros/exercicio_04.csv");
    }
}
