package FichaPratica06;

public class LeituraConsola {

}
