package FichaPratica03;

public class Ex_01 {
    public static void main(String[] args) {

        // Declarar variáveis
        int contador=1;

        while (contador<=250){
            System.out.println(contador);

            // Somar 1 ao contador
            contador=contador+1;
        }
    }
}
