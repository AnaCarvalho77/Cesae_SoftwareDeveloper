package FichaPratica03;

public class Ex_03 {
    public static void main(String[] args) {


        // Declarar variáveis
        int contador = 531;

        while (contador <= 750) {

            System.out.println(contador);

            // Somar 2 ao contador
            contador = contador + 2;
        }

    }
}
