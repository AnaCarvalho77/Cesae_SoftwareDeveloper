package FichaPratica03;

public class Ex_02 {
    public static void main(String[] args) {

        // Declarar variáveis
        int contador = 2;

        while (contador <= 400) {

            System.out.println(contador);

            // Somar 2 ao contador
            contador = contador + 2;
        }

    }
}
