package FichaPratica05;

import java.util.Scanner;

import static FichaPratica06.BibliotecaMatrizes.imprimirMatrizInteiros;

public class Ex_08 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Declarar variáveis
        int[][] matriz = new int[3][3];

        // Ler matriz
        for (int linha = 0; linha < 3; linha++) {
            for (int coluna = 0; coluna < 3; coluna++) {
                System.out.print("Insira na matriz[" + linha + "][" + coluna + "]: ");
                matriz[linha][coluna] = input.nextInt();
            }
        }

        // Imprimir a matriz na consola
        imprimirMatrizInteiros(matriz);


    }
}
