package FichaPraticaExtra_Ciclos;

public class Ex_01 {
    public static void main(String[] args) {

        System.out.println("***** Exercício 1 *****");

        // Ciclo for para imprimir números de 1 a 500
        for (int i = 0; i <= 500; i++) {
            System.out.println(i);
        }

    }
}