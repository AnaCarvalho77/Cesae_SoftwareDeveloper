package FichaPraticaExtra_Ciclos;

public class Ex_02 {
    public static void main(String[] args) {

        System.out.println("***** Exercício 2 *****");

        // Ciclo for para imprimir números de 3 até 255
        // O incremento é de 3 em 3
        for (int i = 3; i <= 255; i += 3) {
            System.out.println(i);
        }

    }
}