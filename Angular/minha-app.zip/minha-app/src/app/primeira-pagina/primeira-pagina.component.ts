import { Component } from '@angular/core';

@Component({
  selector: 'app-primeira-pagina',
  standalone: true,
  imports: [],
  templateUrl: './primeira-pagina.component.html',
  styleUrl: './primeira-pagina.component.scss'
})
export class PrimeiraPaginaComponent {

}
